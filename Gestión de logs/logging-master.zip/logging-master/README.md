# Logging module
The logging module is an agent-based architecture for gathering logs of all components of the PrivApp platform. It is decoupled from the Platform, so any component only needs to write logs to a local file and no more. An independent beat agent will then send the logs to a server and a user can visualize and analyze them.  

![Alt architecture](logging_module.png)

## Requisites

- Configure server: see [server/README.md](server)
- Configure agents: see [agent/README.md](agent)
